#include<stdio.h>
struct Student
{
char name[100];
int id;
double score;
};

